import { Link } from "react-router-dom";

const Header = ({ cartCount = 0 }) => {
  return (
    <header className="bg-white shadow-sm sticky-top" style={{ zIndex: 50 }}>











      <div className="container d-flex justify-content-between align-items-center py-3">
        <Link to="/" className="fs-3 fw-bold text-primary text-decoration-none">
          E-Commerce
        </Link>

        <nav className="d-none d-md-flex gap-4 fw-medium">
          <Link to="/products" className="text-secondary text-decoration-none">
            Products
          </Link>
        </nav>

        <div className="d-flex gap-3">
          <div className="header-wishlist-cart-btn pt-2">
            <Link to="/cart">

            
            <button type="button">
              <i className="icon-shopping-cart"></i>
              {cartCount > 0 && (
              <span className="count">
                {cartCount}
              </span>
            )}
            </button>
            </Link>
          </div>

          <div className="header-search-box">
            <form action="#" method="post">
              <div className="form-group">
                <input
                  type="search"
                  name="search"
                  placeholder="search"
                  required
                />

                <button type="submit">
                  <i className="icon-search-interface-symbol"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
